do_rf_conditional <-
function(X,classlabels, ntrees=500, analysismode="classification"){
	
	#classlabels<-c(rep("A",6),rep("B",6))
	
	dataA<-t(X)
	dataA<-as.data.frame(dataA)
	dataA<-cbind(classlabels,dataA)
	dataA<-as.data.frame(dataA)
	
	colnames(dataA)<-c("Targetvar",paste("mz",seq(1,dim(X)[1]),sep=""))
	
	dataA<-as.data.frame(dataA)
	
	attach(dataA,warn.conflicts=FALSE)
	
	#if(dim(dataA)[2]<500){
		
	#	num_trees=5000
		
	#}else{
	#	num_trees=dim(dataA)[2]
	#	}
	mtry_num<-if (!is.null(classlabels) && !is.factor(classlabels))
                  max(floor(ncol(X)/3), 1) else floor(sqrt(ncol(X)))

	#print("here")
	#set.seed(42)
	set.seed(290875)
      # rf1 <- cforest(factor(nativeSpeaker) ~ ., data = readingSkills, 
       #     control = cforest_unbiased(mtry = 2, ntree = 50))
	#rf1<-cforest(factor(Targetvar)~.,data=dataA,control=cforest_unbiased(mtry=2,ntree=50))
	#print(rf1)
	#if(FALSE)
	{
	if(analysismode=="classfication"){
	rf1<-cforest(factor(Targetvar)~.,data=dataA,control=cforest_control(teststat = "quad",
                     testtype = "Univ",
                     mincriterion = qnorm(0.8),
                     savesplitstats = FALSE,
                     ntree = ntrees, mtry = mtry_num, replace = TRUE,
                     fraction = 0.632, trace = FALSE))
    	}else{
   		
   		rf1<-cforest(Targetvar~.,data=dataA,control=cforest_control(teststat = "quad",
                     testtype = "Univ",
                     mincriterion = qnorm(0.9),
                     savesplitstats = FALSE,
                     ntree = ntrees, mtry = mtry_num, replace = TRUE,
                     fraction = 0.632, trace = FALSE))
   		}
	}
	set.seed(290875)
	varimp_res<-varimpAUC(rf1,conditional=TRUE)
	print(varimp_res)
    rm(dataA) 
        
	#return(varimp_res)
     return(list("rfcond_model"=rf1,"rfcond_varimp"=varimp_res))    

}
