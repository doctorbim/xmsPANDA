get_hca_child <-
function(feature_table_file,parentoutput_dir,class_labels_file,heatmap.col.opt="RdBu",cor.method="spearman",is.data.znorm=FALSE,analysismode="classification",
sample.col.opt="rainbow",plots.width=2000,plots.height=2000,plots.res=300, alphacol=0.3, hca_type)
{
    data_matrix<-read.table(feature_table_file,sep="\t",header=TRUE)
    
    
    dir.create(parentoutput_dir)
    setwd(parentoutput_dir)
    
    data_m<-data_matrix[,-c(1:2)]
    
    data_m<-as.matrix(data_m)
    
    col_samples<-TRUE
    if(is.na(class_labels_file)==FALSE){
        classlabels<-read.table(class_labels_file,sep="\t",header=TRUE)
    }else{
        
        classlabels<-rep("classA",dim(data_m)[2])
        classlabels<-cbind(classlabels,classlabels)
        
        col_samples<-FALSE
        
    }
    
    
    #patientcolors<-rep("green",dim(data_m)[2])
    
    class_labels_levels<-levels(as.factor(classlabels[,2]))
    ordered_labels<-classlabels[,2]
    
    #class_label_alphabets<-c("A","B","C","D","E","F","G","H","I","J","K","L","M")
    class_label_alphabets<-paste("C",1:length(class_labels_levels),sep="")
    
    if(sample.col.opt=="default"){
        
        col_vec<-c("#CC0000","#AAC000","blue","mediumpurple4","mediumpurple1","blueviolet","cornflowerblue","cyan4","skyblue",
        "darkgreen", "seagreen1", "green","yellow","orange","pink", "coral1", "palevioletred2",
        "red","saddlebrown","brown","brown3","white","darkgray","aliceblue",
        "aquamarine","aquamarine3","bisque","burlywood1","lavender","khaki3","black")
        
    }else{
        if(sample.col.opt=="topo"){
            #col_vec<-topo.colors(256) #length(class_labels_levels))
            
            #col_vec<-col_vec[seq(1,length(col_vec),)]
            
            col_vec <- topo.colors(length(class_labels_levels), alpha=alphacol)
        }else{
            if(sample.col.opt=="heat"){
                #col_vec<-heat.colors(256) #length(class_labels_levels))
                
                col_vec <- heat.colors(length(class_labels_levels), alpha=alphacol)
            }else{
                if(sample.col.opt=="rainbow"){
                    #col_vec<-heat.colors(256) #length(class_labels_levels))
                    col_vec<-rainbow(length(class_labels_levels), start = 0, end = alphacol)
                    
                    #col_vec <- heat.colors(length(class_labels_levels), alpha=alphacol)
                }else{
                    
                    if(sample.col.opt=="terrain"){
                        #col_vec<-heat.colors(256) #length(class_labels_levels))
                        #col_vec<-rainbow(length(class_labels_levels), start = 0, end = alphacol)
                        
                        col_vec <- cm.colors(length(class_labels_levels), alpha=alphacol)
                    }
                    
                    
                }
                
            }
            
        }
    }
    if(analysismode=="classification")
    {
        
        sampleclass<-{}
        patientcolors<-{}
        #print(classlabels)
        classlabels<-as.data.frame(classlabels)
        f<-factor(classlabels[,1])
        
        for(c in 1:length(class_labels_levels)){
            
            num_samps_group_cur=length(which(ordered_labels==class_labels_levels[c]))
            
            #classlabels<-c(classlabels,rep(paste("Class",class_label_alphabets,sep=""),num_samps_group_cur))
            #,rep("ClassB",num_samps_group[[2]]),rep("ClassC",num_samps_group[[3]]))
            sampleclass<-c(sampleclass,rep(paste("Class",class_label_alphabets[c],sep=""),num_samps_group_cur))
            
            patientcolors <-c(patientcolors,rep(col_vec[c],num_samps_group_cur))
								}
        
        
        
    }
    
    
    heatmap_cols <- colorRampPalette(brewer.pal(10, "RdBu"))(256)
    heatmap_cols<-rev(heatmap_cols)
    
    if(heatmap.col.opt=="topo"){
        heatmap_cols<-topo.colors(256)
    }else{
        if(heatmap.col.opt=="heat"){
            heatmap_cols<-heat.colors(256)
        }
        
    }
    
    
    
    hc <- try(hclust(as.dist(1-WGCNA::cor(data_m,method=cor.method,use="pairwise.complete.obs"))),silent=TRUE) #samples
    
    hr <- try(hclust(as.dist(1-WGCNA::cor(t(data_m),method=cor.method,use="pairwise.complete.obs"))),silent=TRUE) #metabolites
    
    if(is(hr,"try-error") || is(hc,"try-error")){
								
                                print("Hierarchical clustering can not be performed. ")
    }else{
        heatmap_file<-paste("heatmap.tiff",sep="")
        
        tiff(heatmap_file,width=plots.width,height=plots.height,res=plots.res)
        
        if(hca_type=="two-way"){
            
            hc <- try(hclust(as.dist(1-WGCNA::cor(data_m,method=cor.method,use="pairwise.complete.obs"))),silent=TRUE) #samples
            
            if(col_samples==FALSE){
                if(is.data.znorm==FALSE){
                    
                    h73<-heatmap.2(data_m, Rowv=as.dendrogram(hr), Colv=as.dendrogram(hc),  col=heatmap_cols, scale="row",key=TRUE, symkey=FALSE, density.info="none", trace="none", cexRow=1, cexCol=1,xlab="",ylab="", main="")
                }else{
                    h73<-heatmap.2(data_m, Rowv=as.dendrogram(hr), Colv=as.dendrogram(hc),  col=heatmap_cols, scale="none",key=TRUE, symkey=FALSE, density.info="none", trace="none", cexRow=1, cexCol=1,xlab="",ylab="", main="")
                }
                
            }else{

            
            if(is.data.znorm==FALSE){
                
                h73<-heatmap.2(data_m, Rowv=as.dendrogram(hr), Colv=as.dendrogram(hc),  col=heatmap_cols, scale="row",key=TRUE, symkey=FALSE, density.info="none", trace="none", cexRow=1, cexCol=1,xlab="",ylab="", main="", ColSideColors=patientcolors)
            }else{
                h73<-heatmap.2(data_m, Rowv=as.dendrogram(hr), Colv=as.dendrogram(hc),  col=heatmap_cols, scale="none",key=TRUE, symkey=FALSE, density.info="none", trace="none", cexRow=1, cexCol=1,xlab="",ylab="", main="", ColSideColors=patientcolors)
            }
            }
            dev.off()
            
            
            mycl_samples <- cutree(hc, h=max(hc$height)/2)
            mycl_metabs <- cutree(hr, h=max(hr$height)/2)
            
            ord_data<-cbind(mycl_metabs[rev(h73$rowInd)],data_matrix[rev(h73$rowInd),c(1:2)],data_m[rev(h73$rowInd),h73$colInd])
        }
        else{
            
            hc<-seq(1,dim(data_m)[2])
            
            if(col_samples==FALSE){
                if(is.data.znorm==FALSE){
                    
                    h73<-heatmap.2(data_m, Rowv=as.dendrogram(hr), Colv=as.dendrogram(hc),  col=heatmap_cols, scale="row",key=TRUE, symkey=FALSE, density.info="none", trace="none", cexRow=1, cexCol=1,xlab="",ylab="", main="")
                }else{
                    h73<-heatmap.2(data_m, Rowv=as.dendrogram(hr), Colv=as.dendrogram(hc),  col=heatmap_cols, scale="none",key=TRUE, symkey=FALSE, density.info="none", trace="none", cexRow=1, cexCol=1,xlab="",ylab="", main="")
                }
                
            }else{
            if(is.data.znorm==FALSE){
                
                h73<-heatmap.2(data_m, Rowv=as.dendrogram(hr), Colv=NULL,  col=heatmap_cols, scale="row",key=TRUE, symkey=FALSE, density.info="none", trace="none", cexRow=1, cexCol=1,xlab="",ylab="", main="",dendrogram = c("row"))
            }else{
                h73<-heatmap.2(data_m, Rowv=as.dendrogram(hr), Colv=NULL,  col=heatmap_cols, scale="none",key=TRUE, symkey=FALSE, density.info="none", trace="none", cexRow=1, cexCol=1,xlab="",ylab="", main="",dendrogram = c("row"))
            }
            }
            dev.off()
            
            mycl_samples<-seq(1,dim(data_m)[2])
            #mycl_samples <- cutree(hc, h=max(hc$height)/2)
            mycl_metabs <- cutree(hr, h=max(hr$height)/2)
            
            ord_data<-cbind(mycl_metabs[rev(h73$rowInd)],data_matrix[rev(h73$rowInd),c(1:2)],data_m[rev(h73$rowInd),h73$colInd])
            
            
        }
        
        cnames1<-colnames(ord_data)
        cnames1[1]<-"mz_cluster_label"
        colnames(ord_data)<-cnames1
        fname1<-paste("Clustering_based_sorted_intensity_data.txt",sep="")
        write.table(ord_data,file=fname1,sep="\t",row.names=FALSE)
        
        fname2<-paste("Sample_clusterlabels.txt",sep="")
        
        sample_clust_num<-mycl_samples[h73$colInd]
        temp1<-classlabels[h73$colInd,1]
        temp2<-classlabels
        
        #print(head(temp2))
        #temp1<-as.data.frame(temp1)
        
        #print(dim(temp1))
        match_ind<-match(temp1,temp2[,1])
        
        temp3<-temp2[match_ind,]
        
        print(head(temp3))
        temp4<-cbind(temp1,temp3,sample_clust_num)
       
	write.table(temp4,file="s1.txt",sep="\t",row.names=FALSE) 
    #   print(head(temp1))
    #   print(head(temp4))
        
        rnames1<-rownames(temp4)
        temp4<-cbind(rnames1,temp4)
        temp4<-as.data.frame(temp4)
        #temp4<-temp4[,-c(1)]
        # print(temp4[,1:4])
        
        if(analysismode=="regression"){
            
            if(hca_type=="two-way"){
            tiff("Barplot_sample_cluster_ymat.tiff", width=plots.width,height=plots.height,res=plots.res)
            barplot(temp4[,2],col="brown","Y")
            dev.off()
            }else{
                temp5<-apply(temp4[,c(4:5)],2,as.numeric)
                #  print(temp5[1:4]+1)
                #tiff("Barplot_sample_cluster_ymat.tiff", width=plots.width,height=plots.height,res=plots.res)
                pdf("barplot.pdf")
                #barplot(as.vector(as.numeric(temp5[,1])),col="brown","Y")
                barplot(temp5[,1])
                dev.off()
                
            }
            
            
            
        }
        
        write.table(temp4,file=fname2,sep="\t",row.names=FALSE)
        
        
        
        fname3<-paste("Metabolite_clusterlabels.txt",sep="")
        
        mycl_metabs_ord<-mycl_metabs[rev(h73$rowInd)]
        write.table(mycl_metabs_ord,file=fname3,sep="\t",row.names=TRUE)
        
    }
    
}
