do_mean <-
function(x){
	
	mean_val<-mean(x,na.rm=TRUE)
	return(mean_val)
	}
