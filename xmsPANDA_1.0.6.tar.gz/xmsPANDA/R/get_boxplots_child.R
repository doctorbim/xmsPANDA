get_boxplots_child <-
function(X,Y,feature_table_file,parentoutput_dir,class_labels_file,sample.col.opt="rainbow",plots.width=2000,plots.height=2000,plots.res=300, alphacol=0.3)
{
			
			if(is.na(X)==TRUE){
			data_matrix<-read.table(feature_table_file,sep="\t",header=TRUE)
			
			}else{
			
				data_matrix<-X
			}
			if(is.na(Y)==TRUE){
			classlabels<-read.table(class_labels_file,sep="\t",header=TRUE)
			
			}else{
			classlabels<-Y
			
			}
dir.create(parentoutput_dir)
setwd(parentoutput_dir)

data_m<-data_matrix[,-c(1:2)]

data_m<-as.matrix(data_m)

mzvec<-data_matrix[,1]
goodfeats<-data_m			
rm(data_m)

#patientcolors<-rep("green",dim(data_m)[2])

class_labels_levels<-levels(as.factor(classlabels[,2]))
  ordered_labels<-classlabels[,2]
  
  class_label_alphabets<-paste("C",1:length(class_labels_levels),sep="") #c("A","B","C","D","E","F","G","H","I","J","K","L","M")
							

    if(sample.col.opt=="default"){

    col_vec<-c("#CC0000","#AAC000","blue","mediumpurple4","mediumpurple1","blueviolet","cornflowerblue","cyan4","skyblue",
    "darkgreen", "seagreen1", "green","yellow","orange","pink", "coral1", "palevioletred2",
    "red","saddlebrown","brown","brown3","white","darkgray","aliceblue",
    "aquamarine","aquamarine3","bisque","burlywood1","lavender","khaki3","black")
  
		   }else{ 
		if(sample.col.opt=="topo"){
			#col_vec<-topo.colors(256) #length(class_labels_levels)) 
			
			#col_vec<-col_vec[seq(1,length(col_vec),)]
			
			col_vec <- topo.colors(length(class_labels_levels), alpha=alphacol)
		}else{
				if(sample.col.opt=="heat"){
					#col_vec<-heat.colors(256) #length(class_labels_levels))
					
					col_vec <- heat.colors(length(class_labels_levels), alpha=alphacol)
					}else{
								if(sample.col.opt=="rainbow"){
									#col_vec<-heat.colors(256) #length(class_labels_levels))
									col_vec<-rainbow(length(class_labels_levels), start = 0, end = alphacol)
									
									#col_vec <- heat.colors(length(class_labels_levels), alpha=alphacol)
								}else{
									
										if(sample.col.opt=="terrain"){
									#col_vec<-heat.colors(256) #length(class_labels_levels))
									#col_vec<-rainbow(length(class_labels_levels), start = 0, end = alphacol)
									
									col_vec <- cm.colors(length(class_labels_levels), alpha=alphacol)
									}
									
											
									}
							
						}
			
		}	
}

			
            #	print(class_labels_levels)
			
						ordered_labels={}
							num_samps_group<-new("list")
							num_samps_group[[1]]<-0
							groupwiseindex<-new("list")
							groupwiseindex[[1]]<-0
						
							for(c in 1:length(class_labels_levels))
							{
								
								classlabels_index<-which(classlabels[,2]==class_labels_levels[c])
								#ordered_labels<-c(ordered_labels,as.character(classlabels[classlabels_index,2]))
								num_samps_group[[c]]<-length(classlabels_index)
								groupwiseindex[[c]]<-classlabels_index
							}
			
			sampleclass<-{}
						patientcolors<-{}
						#print(classlabels)
						classlabels<-as.data.frame(classlabels)
						
						
						for(c in 1:length(class_labels_levels)){
									
									num_samps_group_cur=length(which(ordered_labels==class_labels_levels[c]))
									
									#classlabels<-c(classlabels,rep(paste("Class",class_label_alphabets,sep=""),num_samps_group_cur))
									#,rep("ClassB",num_samps_group[[2]]),rep("ClassC",num_samps_group[[3]]))
									sampleclass<-c(sampleclass,rep(paste("Class",class_label_alphabets[c],sep=""),num_samps_group_cur))

									patientcolors <-c(patientcolors,rep(col_vec[c],num_samps_group_cur))
								}
						sampleclass<-classlabels

			
#print(length(mzvec))

if(length(mzvec)>4){
max_per_row<-3


par_rows<-ceiling(9/max_per_row)

}else{
max_per_row<-length(mzvec)
par_rows<-1
}

class_labels_levels<-paste("x",seq(1,length(class_labels_levels)),sep="")

file_ind<-0
			boxplots_fname<-paste("boxplots.pdf",sep="")
				#tiff(boxplots_fname, width=plots.width,height=plots.height,res=plots.res, compression="lzw")
				
				#tiff(boxplots_fname, width=2000,height=3000,res=plots.res, compression="lzw")
				pdf(boxplots_fname)
				par(mfrow=c(par_rows,max_per_row))

		for(m in 1:dim(goodfeats)[1])
		{
			if(m%%9==0){
				#dev.off()
				file_ind<-file_ind+1
				boxplots_fname<-paste("boxplots_file",file_ind,".tiff",sep="")
				#tiff(boxplots_fname, width=plots.width,height=plots.height,res=plots.res, compression="lzw")
				#tiff(boxplots_fname, width=2000,height=3000,res=plots.res, compression="lzw")
				#pdf(boxplots_fname)
				par(mfrow=c(par_rows,max_per_row))
			}
			
			round_mzval<-sprintf("%.4f",mzvec[m])
			mzname<-paste("mz ",round_mzval,sep="")
			if(length(class_labels_levels)>=2)
			{
			
					if(length(class_labels_levels)>=1)
					{
					
					t1<-table(sampleclass)
					cur_d<-{}
					for(c in 1:length(class_labels_levels))
					{
					
					
					num_samps_group[[1]]<-t1[1]
					
					cvec<-as.vector(t(goodfeats[m,c(groupwiseindex[[c]])]))
					
					cvec<-replace_outliers(cvec)
					cur_d<-cbind(cur_d,cvec)
					}
					
					cur_d<-as.data.frame(cur_d)
					
					#class_labels_boxplot<-levels(classlabelsA) #paste(seq(1,length(class_labels_levels)),sep="")
					
					#print(class_labels_boxplot)
					colnames(cur_d)<-NULL #paste(seq(1,length(class_labels_levels)),sep="") #as.character(class_labels_levels)
					cur_d<-round(cur_d,2)
					#print(dim(cur_d))
					#print(cur_d[1:4,])
					
					boxplot(cur_d,ylab="Intensity",main=mzname,xaxt="n")
					
					for(i in 1:length(class_labels_levels)){
					axis(side=1,at=c(i),labels=class_labels_levels[i], col=col_vec[i],cex.axis=0.6)
					
					#text(, round(pcavar1,2), labels = round(pcavar1,2), pos = 3)
					}
					
					}
					
					
					
			}else{

			boxplot(x1,x2, ylab="Intensity",main=mzname)
		axis(side=1,at=seq(1),labels=class_labels_levels[1], col="red")
			axis(side=1,at=2,labels=class_labels_levels[2],col="green")
			}
		}
		dev.off()
	}
