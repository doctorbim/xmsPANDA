diffexp <-
function(Xmat=NA,Ymat=NA,feature_table_file,parentoutput_dir,class_labels_file,num_replicates=3,feat.filt.thresh=NA,summarize.replicates=TRUE,summary.method="mean",summary.na.replacement="zeros",missing.val=0,rep.max.missing.thresh=0.5,
 all.missing.thresh=0.1,group.missing.thresh=0.7,input.intensity.scale="raw",
log2transform=TRUE,medcenter=FALSE,znormtransform=FALSE,quantile_norm=TRUE,lowess_norm=FALSE,madscaling=FALSE,rsd.filt.list=seq(0,75,5),
pairedanalysis=FALSE,featselmethod="limma",fdrthresh=0.05,fdrmethod="BH",cor.method="spearman",networktype="complete",abs.cor.thresh=0.4,cor.fdrthresh=0.05,kfold=10,
pred.eval.method="AUC",feat_weight=1,globalcor=TRUE,
target.metab.file=NA,target.mzmatch.diff=10,target.rtmatch.diff=NA,max.cor.num=100, 
samplermindex=NA,pcacenter=FALSE,pcascale=FALSE,numtrees=20000,analysismode="classification",net_node_colors=c("green","red"), net_legend=TRUE,
svm_kernel="radial",heatmap.col.opt="RdBu",sample.col.opt="rainbow",alphacol=0.3,rf_selmethod="rawVIMsig",pls_vip_thresh=1,num_nodes=2,max_varsel=100,pls_ncomp=5,pca.stage2.eval=TRUE,scoreplot_legend=TRUE,pca.global.eval=TRUE,rocfeatlist=seq(2,11,1),rocfeatincrement=TRUE,rocclassifier="svm",foldchangethresh=2,wgcnarsdthresh=20,WGCNAmodules=TRUE,optselect=TRUE,max_comp_sel=1,saveRda=TRUE,legendlocation="topleft",degree_rank_method="diffK",pca.cex.val=4,
pca.ellipse=FALSE,ellipse.conf.level=0.95,pls.permut.count=100,svm.acc.tolerance=5,limmadecideTests=TRUE)
{
	diffexp.res<-diffexp.child(Xmat,Ymat,feature_table_file,parentoutput_dir,class_labels_file,num_replicates,feat.filt.thresh,summarize.replicates,summary.method,summary.na.replacement,missing.val,rep.max.missing.thresh,
	 all.missing.thresh,group.missing.thresh,input.intensity.scale,
log2transform,medcenter,znormtransform,quantile_norm,lowess_norm,madscaling,rsd.filt.list,
pairedanalysis,featselmethod,fdrthresh,fdrmethod,cor.method,networktype,abs.cor.thresh,cor.fdrthresh,kfold,pred.eval.method,feat_weight,globalcor,
target.metab.file,target.mzmatch.diff,target.rtmatch.diff,max.cor.num,samplermindex,pcacenter,pcascale,
numtrees,analysismode,net_node_colors,net_legend,svm_kernel,heatmap.col.opt,sample.col.opt,alphacol,rf_selmethod,pls_vip_thresh,num_nodes,max_varsel, pls_ncomp,pca.stage2.eval,scoreplot_legend,pca.global.eval,rocfeatlist,rocfeatincrement,rocclassifier,foldchangethresh,wgcnarsdthresh,WGCNAmodules,
optselect,max_comp_sel,saveRda,legendlocation,degree_rank_method,pca.cex.val,pca.ellipse,ellipse.conf.level,pls.permut.count,svm.acc.tolerance,limmadecideTests)
	return(diffexp.res)
}
