do_pamr <-
function(X,Y,fdrthresh){
	
	
	library(pamr)
	if(FALSE){
	x=t(leukemia$X)
	genenames=paste("g",as.character(1:nrow(x)),sep="")
	
	mydata<-list(x=x,y=leukemia$Y,geneid=as.character(1:nrow(x)),genenames=genenames)
	mytrain<-   pamr.train(mydata)
	pfdr<-pamr.fdr(mytrain,mydata)
	pamr.listgenes(mytrain, mydata, threshold=0)
	}
	#d1<-list(x=X,y=Y)
	
	d1 <- list(x=as.matrix(X),y=factor(Y), geneid=as.character(1:nrow(X)),
      genenames=paste("g",as.character(1:nrow(X)),sep=""))
     
	p1<-pamr.train(d1)

	p2<-pamr.cv(data=d1,fit=p1,nfold=10)
	
	p3<-pamr.fdr(data=d1,p1)
	
	p4<-pamr.listgenes(fit=p1,data=d1,threshold=p3$results[which(p3$results[,5]<fdrthresh)[1],1])
	
	p4<-as.data.frame(p4)
	
	return(list("pam_model"=p1,"pam_fdreval"=p3,"pam_sigfeat"=p4))
}
