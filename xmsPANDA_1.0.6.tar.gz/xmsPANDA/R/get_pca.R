get_pca <-
function(X,samplelabels,legendlocation="topright",filename=NA,ncomp=5,center=TRUE,scale=TRUE,legendcex=0.5,outloc=getwd(),col_vec=NA,sample.col.opt="default",alphacol=0.3,class_levels=NA,pca.cex.val=3,pca.ellipse=TRUE,ellipse.conf.level=0.5,samplenames=FALSE){
    
    X<-as.matrix(t(X))
    
    #X<-apply(X,2,scale)
    pch.val<-15
    print("Performing PCA")
    print(dim(X))
    #legendlocation="bottomleft"
    #  print(legendlocation)
    samplelabels<-as.data.frame(samplelabels)
    samplelabels<-as.factor(samplelabels[,1])
    l2<-levels(as.factor(samplelabels))
    col_all=topo.colors(256)
    
    t1<-table(samplelabels)
    if(is.na(class_levels)==TRUE){
        
        l1<-levels(as.factor(samplelabels))
    }else{
        l1<-class_levels
        
        
    }
    
    class_labels_levels<-l1
    
    ncomp=min(dim(X)[1],dim(X)[2])
    
    #   p1<-pcaMethods::pca(t(X),method="svd",center=TRUE,scale="uv",cv="q2",nPcs=10)
    metabpcaresultlog2allmetabs5pcs<-mixOmics::pca(X,ncomp=ncomp,center=TRUE,scale=TRUE)
    
    result<-metabpcaresultlog2allmetabs5pcs
    

    save(result,file="pcares.Rda")
    
    s1<-summary(result)
    r1<-s1$importance[2,]
    r1<-round(r1,2)*100
    if(is.na(col_vec)==TRUE){
        col_vec<-c("mediumpurple4","mediumpurple1","blueviolet","darkblue","blue","cornflowerblue","cyan4","skyblue",
        "darkgreen", "seagreen1", "green","yellow","orange","pink", "coral1", "palevioletred2",
        "red","saddlebrown","brown","brown3","white","darkgray","aliceblue",
        "aquamarine","aquamarine3","bisque","burlywood1","lavender","khaki3","black")
        
    }
    
    if(sample.col.opt=="default"){
        
        col_vec<-c("#CC0000","#AAC000","blue","mediumpurple4","mediumpurple1","blueviolet","cornflowerblue","cyan4","skyblue",
        "darkgreen", "seagreen1", "green","yellow","orange","pink", "coral1", "palevioletred2",
        "red","saddlebrown","brown","brown3","white","darkgray","aliceblue",
        "aquamarine","aquamarine3","bisque","burlywood1","lavender","khaki3","black")
        
    }else{
        if(sample.col.opt=="topo"){
            #col_vec<-topo.colors(256) #length(class_labels_levels))
            
            #col_vec<-col_vec[seq(1,length(col_vec),)]
            
            col_vec <- topo.colors(length(class_labels_levels), alpha=alphacol)
        }else{
            if(sample.col.opt=="heat"){
                #col_vec<-heat.colors(256) #length(class_labels_levels))
                
                col_vec <- heat.colors(length(class_labels_levels), alpha=alphacol)
            }else{
                if(sample.col.opt=="rainbow"){
                    #col_vec<-heat.colors(256) #length(class_labels_levels))
                    col_vec<-rainbow(length(class_labels_levels), start = 0, end = alphacol)
                    
                    #col_vec <- heat.colors(length(class_labels_levels), alpha=alphacol)
                }else{
                    
                    if(sample.col.opt=="terrain"){
                        #col_vec<-heat.colors(256) #length(class_labels_levels))
                        #col_vec<-rainbow(length(class_labels_levels), start = 0, end = alphacol)
                        
                        col_vec <- cm.colors(length(class_labels_levels), alpha=alphacol)
                    }
                    
                    
                }
                
            }
            
        }
    }
    #col_vec<-col_vec[sample(1:length(col_vec),length(col_vec))]
    
    l1<-gsub(x=l1,pattern="Class",replacement="")
    
    dir.create(outloc,showWarnings=FALSE)
    setwd(outloc)
    print(paste("Generating PCA plots",sep=""))
    
    fname<-paste("PCA_eval",filename,".tiff",sep="")
    ## 1) raw data
    #tiff(fname,res=300, width=2000,height=2000)
    col <- rep(col_vec[1:length(t1)], t1)
	print(t1)
	print(length(col))
	print(col)
    #col<-rep(col_all[1:length(l1)],t1)
    ## Choose different size of points
    cex <- rep(pca.cex.val, dim(X)[1])
    ## Choose the form of the points (square, circle, triangle and diamond-shaped
    
    pch_vec<-seq(1,50) #c(3,5,7,9,12,13,2,17,21) #seq(1,50) #
    pch <- rep(pch.val,dim(X)[1])
    cex <- rep(pca.cex.val, dim(X)[1])
    for(p1 in 1:length(l2)){
        
        pch[which(samplelabels==l2[p1])]=pch_vec[p1]
    }
   
   
   
   main_text=paste("Pairwise PC score plots using ",filename," features after preprocessing",sep="")
   
	   legendcex<-0.9 #0.5*pca.cex.val

   if(pca.ellipse=="car"){
      
      
      col<-col_vec[1:length(t1)]
      cex <- rep(legendcex,length(t1))
      pch <- unique(pch) #rep(15,length(t1))
      
      
      print(dataEllipse(x=result$x[,1], y=result$x[,2],groups=as.factor(samplelabels),grid=TRUE,lwd=4,levels=c(ellipse.conf.level),col=col,pch=pch,xlab=paste("PC1 (",r1[1],"% variation)",sep=""),ylab=paste("PC2 (",r1[2],"% variation)",sep=""),group.labels="",main=main_text,fill=TRUE))
       print(legend(legendlocation, l1, col = col,pch = pch, pt.cex = cex, title = "Class #", cex=legendcex))
       
       
      print(dataEllipse(x=result$x[,1], y=result$x[,3],groups=as.factor(samplelabels),grid=TRUE,lwd=4,levels=c(ellipse.conf.level),col=col,pch=pch,xlab=paste("PC1 (",r1[1],"% variation)",sep=""),ylab=paste("PC3 (",r1[3],"% variation)",sep=""),group.labels="",main=main_text,fill=TRUE))
       print(legend(legendlocation, l1, col = col,pch = pch, pt.cex = cex, title = "Class #", cex=legendcex))
       
       
       print(dataEllipse(x=result$x[,2], y=result$x[,3],groups=as.factor(samplelabels),grid=TRUE,lwd=4,levels=c(ellipse.conf.level),col=col,pch=pch,xlab=paste("PC2 (",r1[2],"% variation)",sep=""),ylab=paste("PC3 (",r1[3],"% variation)",sep=""),group.labels="",main=main_text,fill=TRUE))
       print(legend(legendlocation, l1, col = col,pch = pch, pt.cex = cex, title = "Class #", cex=legendcex))
       
   }else{
      
   

    print(plotIndiv(result, comp = c(1,2),ind.names = samplenames,col = col, cex = cex, pch = pch, X.label=paste("PC1 (",r1[1],"% variation)",sep=""),Y.label=paste("PC2 (",r1[2],"% variation)",sep=""),main=main_text,add.legend=FALSE,plot.ellipse=pca.ellipse,ellipse.level=ellipse.conf.level))
 

    fname1<-paste("pcares",filename,"features.Rda",sep="")
    # save(result,samplenames,col,cex,pch,r1,main_text,pca.ellipse,ellipse.conf.level,file=fname1)
	#save(list=ls(),file=fname1)
   
    col<-col_vec[1:length(t1)]
    cex <- rep(legendcex,length(t1))
    pch <- unique(pch) #rep(15,length(t1))
    if(length(t1)>1){
    print(legend(legendlocation, l1, col = col,pch = pch, pt.cex = cex, title = "Class #", cex=legendcex))
    #dataEllipse(x=pcIr@scores[,1], y=pcIr@scores[,2],groups=as.factor(iris[,5]),grid=TRUE,lwd=4,levels=c(0.95),col=c("red","blue","green"),pch=c(1,7,5))
    }
  
 

    col <- rep(col_vec[1:length(t1)], t1)
    pch_vec<-seq(1,50) #c(3,5,7,9,12,13,2,17,21) #seq(1,50) #
    pch <- rep(pch.val,dim(X)[1])
    cex <- rep(pca.cex.val, dim(X)[1])
    for(p1 in 1:length(l2)){
        
        pch[which(samplelabels==l2[p1])]=pch_vec[p1]
    }
    cex <- rep(pca.cex.val, dim(X)[1])
    print(plotIndiv(result, comp = c(1,3),ind.names = samplenames,col = col, cex = cex, pch = pch, X.label=paste("PC1 (",r1[1],"% variation)",sep=""),Y.label=paste("PC3 (",r1[3],"% variation)",sep=""),main=main_text,add.legend=FALSE,plot.ellipse=pca.ellipse,ellipse.level=ellipse.conf.level))
    col<-col_vec[1:length(t1)]
    cex <- rep(legendcex,length(t1))
    pch <- unique(pch)
     if(length(t1)>1){
    print(legend(legendlocation, l1, col = col,pch = pch, pt.cex = cex, title = "Class #", cex=legendcex))
     }
     
    col <- rep(col_vec[1:length(t1)], t1)
    pch_vec<-seq(1,50) #c(3,5,7,9,12,13,2,17,21) #seq(1,50) #
    pch <- rep(pch.val,dim(X)[1])
    cex <- rep(pca.cex.val, dim(X)[1])
    for(p1 in 1:length(l2)){
        
        pch[which(samplelabels==l2[p1])]=pch_vec[p1]
    }
    cex <- rep(pca.cex.val, dim(X)[1])
    print(plotIndiv(result, comp = c(2,3),ind.names = samplenames,col = col, cex = cex, pch = pch, X.label=paste("PC2 (",r1[2],"% variation)",sep=""),Y.label=paste("PC3 (",r1[3],"% variation)",sep=""),main=main_text,add.legend=FALSE,plot.ellipse=pca.ellipse,ellipse.level=ellipse.conf.level))
    col<-col_vec[1:length(t1)]
    cex <- rep(legendcex,length(t1))
    pch <- unique(pch)
     if(length(t1)>1){
   print(legend(legendlocation, l1, col = col,pch = pch, pt.cex = cex, title = "Class #", cex=legendcex))
     }
    }
    
    
    
    #print(legend(legendlocation, l1, col = col,pch = pch, pt.cex = cex, title = "Class #", cex=legendcex))
    #dataEllipse(x=pcIr@scores[,1], y=pcIr@scores[,2],groups=as.factor(iris[,5]),grid=TRUE,lwd=4,levels=c(0.95),col=c("red","blue","green"),pch=c(1,7,5))
    
    
    print("done with PCA")
    return(result)
}
